		<!-- Required jQuery first, then Bootstrap Bundle JS -->
		<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
		<script src="<?= base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
		<script src="<?= base_url('assets/js/modernizr.js'); ?>"></script>
		<script src="<?= base_url('assets/js/moment.js'); ?>"></script>		

		<!-- Slimscroll JS -->
		<script src="<?= base_url('assets/vendor/slimscroll/slimscroll.min.js'); ?>"></script>
		<script src="<?= base_url('assets/vendor/slimscroll/custom-scrollbar.js'); ?>"></script>

		<!-- Search Filter JS -->
		<script src="<?= base_url('assets/vendor/search-filter/search-filter.js'); ?>"></script>
		<script src="<?= base_url('assets/vendor/search-filter/custom-search-filter.js'); ?>"></script>

		<!-- Main Js Required -->
		<script src="<?= base_url('assets/js/main.js'); ?>"></script>
		<script type="text/javascript">
	$(document).ready(function(){
		$('.dataTable').dataTable();
	});
</script>


<script>
			 function kilo() //kilo
			 {
				 paket = $("#id_paket").val();
				 jml_kilo = $("#jml_kilo").val();
				 if (paket == "")
				 {
					 alert("Pilih Paket Terlebih Dahulu");
				 }
				 else
				 {
					 $.ajax
					 ({
						 url  : "<?= site_url('Transaksi/kilo') ?>",
						 type : "POST",
						 data : {
							 paket : paket,
							 jml_kilo :jml_kilo

						 },
						 success:function (data)
						 {
							 $("#total").val(data);
						 }
					 })
				 }
			 }
			 function printDiv(divName)
			 {
				 let printContents = document.getElementById(divName).innerHTML;
				 let originalContents = document.body.innerHTML;
				 document.body.innerHTML = printContents;
				 window.print();
				 document.body.innerHTML = originalContents;
				 location.reload(true);
				 setTimeout(function() {}, 50);
			 }
		 </script>
	</body>
</html>