<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Bootstrap4 Dashboard Template">
	<meta name="author" content="ParkerThemes">
	<link rel="shortcut icon" href="img/fav.png">
	<title>LAundry KIMClonkUnchh!!!</title>
	<!-- Bootstrap css -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/fonts/style.css'); ?>">
	<!-- Main css -->
	<link rel="stylesheet" href="<?= base_url('assets/css/main.css'); ?>">
	<!-- Mega Menu -->
	<link rel="stylesheet" href="<?= base_url('assets/vendor/megamenu/css/megamenu.css'); ?>">
	<!-- Search Filter JS -->
	<link rel="stylesheet" href="<?= base_url('assets/vendor/search-filter/search-filter.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/vendor/search-filter/custom-search-filter.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/vendor/fontawesome/css/all.min.css'); ?>">
</head>

<body class="compact-sidebar">

	<!-- Loading wrapper start -->
	<!-- <div id="loading-wrapper">
			<div class="spinner-border"></div>
		</div> -->
	<!-- Loading wrapper end -->

	<!-- Page wrapper start -->
	<div class="page-wrapper">

		<!-- Sidebar wrapper start -->
		<nav class="sidebar-wrapper">

			<!-- Compact sidebar wrapper start -->
			<div class="compact-sidebar-wrapper">

				<!-- Sidebar brand starts -->
				<div class="compact-sidebar-brand">
					<a href="index.html" class="logo">
						<img src="<?= base_url('assets/img/laundry.png'); ?>" alt="KIMCLONG" />
						<h4 class="m-lg-2">KimClonk</h4>
					</a>
				</div>
				<!-- Sidebar brand starts -->

				<!-- Sidebar menu starts -->
				<div class="compactSidebarMenuScroll">
					<div class="compact-sidebar-menu">
						<ul>
							<!-- admin -->
							<?php if ($this->session->userdata('role') === 'Admin')  : ?>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Outlet' ? 'active' : null ?>">
									<a href="<?= base_url('Outlet'); ?>">
										<i class="fas fa-store"></i>
										<span class="menu-text">outlet</span>
									</a>
								</li>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Admin' ? 'active' : null ?>">
									<a href="<?= base_url('Admin'); ?>">
										<i class="fas fa-user"></i>
										<span class="menu-text">Pengguna</span>
									</a>
								</li>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Pelanggan' ? 'active' : null ?>">
									<a href="<?= base_url('Pelanggan'); ?>">
									<i class="fas fa-users"></i>
										<span class="menu-text">Pelanggan</span>
									</a>
								</li>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Paket' ? 'active' : null ?>">
									<a href="<?= base_url('Paket'); ?>">
										<i class="fas fa-box"></i>
										<span class="menu-text">Paket</span>
									</a>
								</li>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Transaksi' ? 'active' : null ?>">
									<a href="<?= base_url('Transaksi'); ?>">
										<i class="fas fa-money-bill"></i>
										<span class="menu-text">Transaksi</span>
									</a>
								</li>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Laporan' ? 'active' : null ?>">
									<a href="<?= base_url('Laporan'); ?>">
										<i class="fas fa-file"></i>
										<span class="menu-text">Laporan</span>
									</a>
								</li>
								<!-- <li class="compact-sidebar <?= $this->uri->segment(1) == 'outlet' ? 'active' : null ?>">
									<a href="Outlet">
										<i class="icon-unlock"></i>
										<span class="menu-text">Authentication</span>
									</a>
								</li> -->
								<!-- kasir -->
							<?php elseif ($this->session->userdata('role') === 'Kasir') : ?>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Outlet' ? 'active' : null ?>">
									<a href="<?= base_url('Outlet'); ?>">
										<i class="fas fa-store"></i>
										<span class="menu-text">outlet</span>
									</a>
								</li>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Paket' ? 'active' : null ?>">
									<a href="<?= base_url('Paket'); ?>">
										<i class="fas fa-box"></i>
										<span class="menu-text">Paket</span>
									</a>
								</li>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Transaksi' ? 'active' : null ?>">
									<a href="<?= base_url('Transaksi'); ?>">
										<i class="fas fa-money-bill"></i>
										<span class="menu-text">Transaksi</span>
									</a>
								</li>
								<!-- <li class="compact-sidebar <?= $this->uri->segment(1) == 'outlet' ? 'active' : null ?>">
                                        <a href="#">
                                            <i class="icon-unlock"></i>
                                            <span class="menu-text">Authentication</span>
                                        </a>
                                    </li> -->
							<?php elseif ($this->session->userdata('role') === 'Owner') : ?>
								<li class="compact-sidebar <?= $this->uri->segment(1) == 'Laporan' ? 'active' : null ?>">
									<a href="<?= base_url('Laporan'); ?>">
										<i class="fas fa-file"></i>
										<span class="menu-text">Laporan</span>
									</a>
								</li>


							<?php endif; ?>

						</ul>
					</div>
				</div>
				<!-- Sidebar menu ends -->

			</div>
			<!-- Compact sidebar wrapper end -->

		</nav>
		<!-- Sidebar wrapper end -->

		<!-- *************
				************ Main container start *************
			************* -->
		<div class="main-container">

			<!-- Page header starts -->
			<div class="page-header">

				<!-- Row start -->
				<div class="row gutters">
					<div class="col-xl-6 col-lg-6 col-md-8 col-sm-6 col-9">

						<!-- Search container start -->
						<div class="search-container">

							<!-- Toggle sidebar start -->
							<div class="toggle-sidebar" id="toggle-sidebar">
								<i class="icon-menu"></i>
							</div>
							<!-- Toggle sidebar end -->


							<!-- Search input group start -->
							<div class="ui fluid category search">
								<div class="ui icon input">
									<input class="prompt" type="text" placeholder="Search">
									<i class="search icon icon-search"></i>
								</div>
								<div class="results"></div>
							</div>
							<!-- Search input group end -->

						</div>
						<!-- Search container end -->

					</div>
					<div class="col-xl-6 col-lg-6 col-md-4 col-sm-6 col-3">

						<!-- Header actions start -->
						<ul class="header-actions">
							<li class="dropdown">
								<a href="#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
									<span class="avatar">
										<img src="<?= base_url('assets/img/user.svg'); ?>" alt="User Avatar">
										<span class="status busy"></span>
									</span>
								</a>
								<div class="dropdown-menu dropdown-menu-end md" aria-labelledby="userSettings">
									<div class="header-profile-actions">
										<a href="<?= base_url('Admin/keluar'); ?>"><i class="icon-log-out1"></i>Logout</a>
									</div>
								</div>
							</li>
						</ul>
						<!-- Header actions end -->

					</div>
				</div>
				<!-- Row end -->

			</div>
			<!-- Page header ends -->