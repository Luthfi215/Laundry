<!-- Content wrapper scroll start -->
<div class="content-wrapper-scroll">
    <!-- Content wrapper start -->
    <div class="content-wrapper">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12">
                <h1 class="h4  mb-4 text-gray-800">Tambah member</h1>
                <!-- Card start -->
                <div class="card card-shadow mb-4">
                    <!-- konten -->
                    <div class="card-body">
                        <form method="post" action="<?php echo base_url('Pelanggan/tambah') ?>">
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" name="nama">
                                    <?= form_error('nama', '<small class="text-danger">', '</small> ');?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" name="alamat">
                                    <?= form_error('alamat', '<small class="text-danger">', '</small> ');?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Jenis Kelamin</label></label>
                                <div class="col-sm-10">
                                    <select class="form-select" aria-label="Default select example" name="jenis_kelamin">
                                        <option selected></option>
                                        <option value="L">L</option>
                                        <option value="P">P</option>
                                    </select>
                                    <?= form_error('jenis_kelamin', '<small class="text-danger">', '</small> ');?>
                                </div>
                            </div>
                            <!-- <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" name="jenis_kelamin"> </input>
                                </div>
                            </div> -->
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Nomor Telepon</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" id="inputPassword" name="tlp"> </input>
                                    <?= form_error('tlp', '<small class="text-danger">', '</small> ');?>
                                </div>
                            </div>
                            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'pelanggan/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>


                            <input type="submit" class="btn btn-success " value="Tambah">
                        </form>

                    </div>

                </div>
                <!-- Card end -->
            </div>
        </div>
        <!-- Row end -->
    </div>
    <!-- Content wrapper end -->

    <!-- App Footer start -->
    <div class="app-footer">© Uni Pro Admin 2021</div>
    <!-- App footer end -->

</div>
<!-- Content wrapper scroll end -->

</div>
<!-- *************
            ************ Main container end *************
        ************* -->
</div>
<!-- Page wrapper end -->