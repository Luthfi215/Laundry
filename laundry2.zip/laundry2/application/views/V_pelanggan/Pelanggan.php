            <!-- Content wrapper scroll start -->
            <div class="content-wrapper-scroll">
                <!-- Content wrapper start -->
                <div class="content-wrapper">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12">
                            <!-- Card start -->
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">Data Pelanggan</div>
                                </div>
                                <!-- konten -->
                                <div class="card-body">
                                    <!-- Place your content here -->
                                    <a class="btn btn-primary" href="<?php echo base_url() . 'Pelanggan/tambah' ?>" role="button">Tambah Data Pelanggan</a><br />
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                                    <colgroup>
                                                        <col width="2%">
                                                        <col width="15%">
                                                        <col width="15%">
                                                        <col width="5%">
                                                        <col width="15%">
                                                    </colgroup>
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center">id</th>
                                                            <th class="text_center">Nama</th>
                                                            <th class="text-center">Alamat</th>
                                                            <th class="text-center">Jenis kelamin</th>
                                                            <th class="text-center">NomorTelepon</th>

                                                            <th class="text-center">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $no = 1; ?>
                                                        <?php foreach ($member as $mm) : ?>
                                                            <tr>
                                                                <th class="text-center" scope="row"><?= $no; ?></th>
                                                                <td><?= $mm->nama; ?></td>
                                                                <td><?= $mm->alamat; ?></td>
                                                                <td><?= $mm->jenis_kelamin; ?></td>
                                                                <td><?= $mm->tlp; ?></td>

                                                                <td class="text-center">
                                                                    <a href="<?php echo base_url() . 'Pelanggan/edit/' . $mm->id_member; ?>"  role="button" class="btn btn-warning btn-sm"> Edit Data Member </a>
                                                                    <a href="<?php echo base_url() . 'Pelanggan/member_hapus/' . $mm->id_member; ?>" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger btn-sm"> Hapus Data Member</a>
                                                                </td>
                                                            </tr>
                                                            <?php $no++; ?>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <!-- Card end -->
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
                <!-- Content wrapper end -->

                <!-- App Footer start -->
                <div class="app-footer">© Uni Pro Admin 2021</div>
                <!-- App footer end -->

            </div>
            <!-- Content wrapper scroll end -->

            </div>
            <!-- *************
            ************ Main container end *************
        ************* -->
            </div>
            <!-- Page wrapper end -->