          <!-- Content wrapper scroll start -->
            <div class="content-wrapper-scroll">
                <!-- Content wrapper start -->
                <div class="content-wrapper">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12">
                            <!-- Card start -->
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">PAKET</div>
                                </div>
                                <!-- konten -->
                                <div class="card-body">
                                    <!-- Place your content here -->
                                    <a class="btn btn-primary" href="<?php echo base_url() . 'Paket/tambah' ?>" role="button">Tambah Data Paket</a><br />
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                                    <colgroup>
                                                        <col width="2%">
                                                        <col width="5%">
                                                        <col width="5%">
                                                        <col width="5%">
                                                        <col width="5%">
                                                    </colgroup>
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center">id</th>
                                                            <th class="text_center">Jenis</th>
                                                            <th class="text-center">Nama Paket</th>
                                                            <th class="text-center">Harga</th>

                                                            <th class="text-center">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $no = 1; ?>
                                                        <?php foreach ($paket as $md) : ?>
                                                            <tr>
                                                                <th class="text-center" scope="row"><?= $no; ?></th>
                                                                <td><?= $md->jenis; ?></td>
                                                                <td><?= $md->nama_paket; ?></td>
                                                                <td><?= $md->harga; ?></td>

                                                                <td class="text-center">
                                                                    <a href="<?php echo base_url() . 'Paket/edit/' . $md->id_paket; ?>" role="button" class="btn btn-warning btn-sm"> Edit Data paket  </a>
                                                                    <a href="<?php echo base_url() . 'Paket/member_hapus/' . $md->id_paket; ?>" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger btn-sm"> Hapus Data paket</a>
                                                                </td>
                                                            </tr>
                                                            <?php $no++; ?>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <!-- Card end -->
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
                <!-- Content wrapper end -->

                <!-- App Footer start -->
                <div class="app-footer">© Uni Pro Admin 2021</div>
                <!-- App footer end -->

            </div>
            <!-- Content wrapper scroll end -->

            </div>
            <!-- *************
            ************ Main container end *************
        ************* -->
            </div>
            <!-- Page wrapper end -->