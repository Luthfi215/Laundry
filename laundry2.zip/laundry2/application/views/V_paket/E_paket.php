<!-- Content wrapper scroll start -->
<div class="content-wrapper-scroll">
    <!-- Content wrapper start -->
    <div class="content-wrapper">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12">
                <h1 class="h4  mb-4 text-gray-800">Edit data paket</h1>
                <!-- Card start -->
                <div class="card card-shadow mb-4">
                    <!-- konten -->
                    <div class="card-body">
                            <form method="post" action="<?php echo base_url('paket/edit/'.$paket['id_paket']) ?>">
                                <!-- <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                                    <div class="col-sm-10">
                                        
                                    </div>
                                </div> -->
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Jenis</label></label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="jenis" >
                                            <option value="<?= $paket['jenis']?>"><?= $paket['jenis']?></option>
                                        <option selected></option>
                                        <option value="kiloan">kiloan</option>
                                        <option value="selimut">selimut</option>
                                        <option value="bed_cover">bed cover</option>
                                        <option value="kaos">kaos</option>
                                        <option value="lain">Lain-lain</option>
                                    </select>
                                    <?= form_error('jenis', '<small class="text-danger">', '</small> ');?>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nama paket</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="nama_paket" value="<?= $paket['nama_paket']?>"> </input>
                                        <?= form_error('nama_paket');?> 
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Harga</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" id="inputPassword" name="harga" value="<?= $paket['harga']?>"> </input>
                                        <?= form_error('harga');?>
                                    </div>
                                </div>
                                <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'paket/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>


                                <input type="submit" class="btn btn-success " value="Update Data Pengguna">
                            </form>

                    </div>

                </div>
                <!-- Card end -->
            </div>
        </div>
        <!-- Row end -->
    </div>
    <!-- Content wrapper end -->

    <!-- App Footer start -->
    <div class="app-footer">© Uni Pro Admin 2021</div>
    <!-- App footer end -->

</div>
<!-- Content wrapper scroll end -->

</div>
<!-- *************
            ************ Main container end *************
        ************* -->
</div>
<!-- Page wrapper end -->