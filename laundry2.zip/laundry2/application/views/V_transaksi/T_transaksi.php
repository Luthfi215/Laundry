<!-- Content wrapper scroll start -->


<div class="content-wrapper-scroll">
    <!-- Content wrapper start -->
    <div class="content-wrapper">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12">
                <h1 class="h4  mb-4 text-gray-800">Tambah transaksi</h1>
                <!-- Card start -->
                <div class="card card-shadow mb-4">
                    <!-- konten -->
                    <div class="card-body">
                        <form method="post" action="<?php echo base_url('transaksi/tambah') ?>">
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">kode invoice</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" name="kode_invoice" value="<?= $no; ?>" readonly>
                                    <?= form_error('kode_invoice'); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Pelanggan</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="id_member">
                                        <option value="">--</option>
                                        <?php foreach ($member as $ff) : ?>
                                            <option value="<?= $ff['id_member']; ?>"><?= $ff['nama']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?= form_error('id_member', '<small class="text-danger">', '</small> '); ?>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">outlet</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="id_outlet">
                                        <option value="">--</option>
                                        <?php foreach ($outlet as $ff) : ?>
                                            <option value="<?= $ff['id_outlet']; ?>"><?= $ff['nama']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?= form_error('id_outlet', '<small class="text-danger">', '</small> '); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">paket</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="id_paket" id="id_paket">
                                        <option value="">--</option>
                                        <?php foreach ($paket as $md) : ?>
                                            <option value="<?= $md['id_paket']; ?>"><?= $md['nama_paket']; ?> ( Rp. <?= number_format($md['harga'], 0, ",", ","); ?> ) </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?= form_error('id_paket', '<small class="text-danger">', '</small> '); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Bayar</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" name="bayar" id="total" readonly> </input>
                                    <?= form_error('bayar'); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Jumlah Kilo</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" id="jml_kilo" name="jml_kilo" onkeyup="kilo()"> </input>
                                    <?= form_error('jml_kilo', '<small class="text-danger">', '</small> '); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Tanggal Order</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" name="tgl"> </input>
                                    <?= form_error('tgl', '<small class="text-danger">', '</small> '); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Status</label></label>
                                <div class="col-sm-10">
                                    <select class="form-select" aria-label="Default select example" name="status" readonly>
                                        <option value="baru" selected>Baru</option>
                                    </select>
                                    <?= form_error('status', '<small class="text-danger">', '</small> '); ?>
                                </div>
                            </div>
                            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'Transaksi/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>

                            <input type="submit" class="btn btn-success " value="Tambah">
                        </form>

                    </div>

                </div>