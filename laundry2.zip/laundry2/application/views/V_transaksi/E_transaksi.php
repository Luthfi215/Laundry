<!-- Content wrapper scroll start -->
<div class="content-wrapper-scroll">
    <!-- Content wrapper start -->
    <div class="content-wrapper">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12">
                <h1 class="h4  mb-4 text-gray-800">Edit transaksi</h1>
                <!-- Card start -->
                <div class="card card-shadow mb-4">
                    <!-- konten -->
                    <div class="card-body">
                        <form method="post" action="<?php echo base_url('transaksi/edit/' . $transaksi['id_transaksi']) ?> " readonly>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Kode invoice</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" name="kode_invoice" value="<?= $transaksi['kode_invoice'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Pelanggan</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="id_member" readonly>
                                        <option value="<?= $transaksi['id_member']; ?>"><?= $transaksi['nama']; ?></option>
                                    </select>
                                    <?= form_error('id_member'); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label"> outlet</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="id_outlet" readonly>
                                        <option value="<?= $transaksi2['id_outlet']; ?>"><?= $transaksi2['nama']; ?></option>
                                    </select>
                                    <?= form_error('id_outlet'); ?>

                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">paket</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="id_paket" readonly>
                                        <option value="<?= $transaksi3['id_paket']; ?>"><?= $transaksi3['nama_paket']; ?></option>
                                        <?php foreach ($paket as $ff) : ?>
                                            <option value="<?= $ff['id_paket']; ?>"><?= $ff['nama_paket']; ?> ( Rp. <?= number_format($ff['harga'], 0, ",", ","); ?> ) </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?= form_error('id_paket'); ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Bayar</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control"  name="bayar" id="total" value="<?= $transaksi['bayar'] ?>" readonly> </input>
                                    <?= form_error('bayar'); ?>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Tanggal</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" id="inputPassword" name="tgl" onkeyup="kilo()" value="<?= $transaksi['tgl'] ?>" readonly> </input>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Tanggal Ambil</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" id="inputPassword" name="tgl_bayar" onkeyup="kilo()" value="<?= $transaksi['tgl_bayar'] ?>" > </input>
                                    <?= form_error('tgl_bayar', '<small class="text-danger">', '</small> ') ?>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">jumlah kilo</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" id="inputPassword" name="jml_kilo" value="<?= $transaksi['jml_kilo'] ?>" readonly> </input>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Status</label></label>
                                <div class="col-sm-10">
                                    <select class="form-select" aria-label="Default select example" name="status">
                                        <option value="<?= $transaksi['status'] ?>"><?= $transaksi['status'] ?></option>
                                        <option></option>
                                        <option value="baru">Baru</option>
                                        <option value="proses">proses</option>
                                        <option value="selesai">selesai</option>
                                        <option value="diambil">diambil</option>
                                        <?= form_error('dibayar'); ?>
                                    </select>
                                </div>
                            </div>
                            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'Transaksi/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>


                            <input type="submit" class="btn btn-success " value="Update Data Pengguna">
                        </form>

                    </div>

                </div>
                <!-- Card end -->
            </div>
        </div>
        <!-- Row end -->
    </div>
    <!-- Content wrapper end -->

    <!-- App Footer start -->
    <div class="app-footer">© Uni Pro Admin 2021</div>
    <!-- App footer end -->

</div>
<!-- Content wrapper scroll end -->

</div>
<!-- *************
            ************ Main container end *************
        ************* -->
</div>
<!-- Page wrapper end -->