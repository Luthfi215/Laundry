
<!-- Content wrapper scroll start -->
  <div class="content-wrapper-scroll">
      <!-- Content wrapper start -->
      <div class="content-wrapper">
          <!-- Row start -->
          <div class="row gutters">
              <div class="col-xl-12">
                  <!-- Card start -->
                  <div class="card">
                      <div class="card-header">
                          <div class="card-title">Transaksi</div>
                      </div>
                      <!-- konten -->
                      <div class="card-body">
                          <div class="table-resposive" id="print-area">
                              <!-- Place your content here -->
                              <a class="btn btn-primary" href="<?php echo base_url() . 'Transaksi/tambah' ?>" role="button">Tambah Data Transaksi</a><br />
                              <div class="card shadow mb-4">
                                  <div class="card-body">
                                      <div class="table-responsive">
                                          <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                              <colgroup>
                                                  <col width="2%">
                                                  <col width="15%">
                                                  <col width="15%">
                                                  <col width="15%">
                                                  <col width="15%">
                                              </colgroup>
                                              <thead>
                                                  <tr>
                                                      <th class="text-center">No</th>
                                                      <th>Kode Invoice</th>
                                                      <th>Pelanggan</th>
                                                      <th>Bayar</th>
                                                      <th>Status</th>
                                                      <th>Tanggal Order</th>
                                                      <th>Tanggal Ambil</th>
                                                      <th class="text-center">Aksi</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                                  <?php $no = 1; ?>
                                                  <?php foreach ($transaksi as $ff) : ?>
                                                      <tr>
                                                          <th scope="row"><?php echo $no++; ?></th>
                                                          <td><?php echo $ff->kode_invoice; ?></td>
                                                          <td class="text-center"><?php echo $ff->nama; ?></td>
                                                          <td><?php echo $ff->bayar; ?></td>
                                                          <td><?php echo $ff->status; ?></td>
                                                          <td><?php echo $ff->tgl; ?></td>
                                                          <td><?php echo $ff->tgl_bayar; ?></td>

                                                          <td class="text-center">
                                                              <a href="<?php echo base_url() . 'Transaksi/edit/' . $ff->id_transaksi; ?>" role="button" class="btn btn-warning btn-sm"> detail </a>
                                                              <!-- <button >Open Modal</button> -->
                                                          </td>
                                                      </tr>
                                                      <?php $no++; ?>
                                                  <?php endforeach; ?>
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>

                          </div>

                      </div>