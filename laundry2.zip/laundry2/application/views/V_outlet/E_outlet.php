<!-- Content wrapper scroll start -->
<div class="content-wrapper-scroll">
    <!-- Content wrapper start -->
    <div class="content-wrapper">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12">
                <h1 class="h4  mb-4 text-gray-800">Edit Outlet</h1>
                <!-- Card start -->
                <div class="card card-shadow mb-4">
                    <!-- konten -->
                    <div class="card-body">
                            <form method="post" action="<?php echo base_url('outlet/edit/'.$outlet['id_outlet']) ?>">
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="nama" value="<?= $outlet['nama']?>">
                                        <?= form_error('nama', '<small class="text-danger">', '</small> ');?>
                                    </div>
                                </div>
                                <!-- <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">role</label></label>
                                    <div class="col-sm-10">
                                        <select class="form-select" aria-label="Default select example" name="role" >
                                            
                                            <option>-</option>
                                            <option value="Kasir">Kasir</option>
                                            <option value="Owner">Owner</option>
                                        </select>
                                    </div>
                                </div> -->
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Alamat</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="inputPassword" name="alamat" value="<?= $outlet['alamat']?>"> </input>
                                        <?= form_error('alamat', '<small class="text-danger">', '</small> ');?>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">Telepon</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" id="inputPassword" name="tlp" value="<?= $outlet['tlp']?>"> </input>
                                        <?= form_error('tlp', '<small class="text-danger">', '</small> ');?>
                                    </div>
                                </div>
                                <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'outlet/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>

                                <input type="submit" class="btn btn-success " value="Update Data Pengguna">
                            </form>
                            
                        </div>
                        
                    </div>
                    <!-- Card end -->
                </div>
            </div>
            <!-- Row end -->
        </div>
    <!-- Content wrapper end -->

    <!-- App Footer start -->
    <div class="app-footer">© Uni Pro Admin 2021</div>
    <!-- App footer end -->
       
</div>

<!-- Content wrapper scroll end -->

</div>
<!-- *************
            ************ Main container end *************
        ************* -->
</div>
<!-- Page wrapper end -->