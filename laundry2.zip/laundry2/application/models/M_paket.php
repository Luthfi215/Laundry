<?php
defined('BASEPATH') or exit('No direct script access allowed');
class  M_paket extends CI_Model
{
    // show user&filter chose role_id
    public function tampil_paket()
    {
         $this->db->order_by('id_paket', 'desc');
        return $this->db->get('tb_paket')->result();
    }

    // tambah user
    public function insert_data()
    {
        $data = array(
            'jenis' => ($this->input->post('jenis')),
            'nama_paket' => ($this->input->post('nama_paket')),
            'harga' => ($this->input->post('harga'))
            // 'password' => ($this->input->post('password'))
        );

        $this->db->insert('tb_paket', $data);
    }
    
    //edit user
    function edit_data($id_paket)
    {
        $data = array(
            'jenis' => ($this->input->post('jenis')),
            'nama_paket' => ($this->input->post('nama_paket')),
            'harga' => ($this->input->post('harga'))
            // 'password' => ($this->input->post('password'))
        );
        $table_paket = $this->db->dbprefix('tb_paket');

        $this->db->where('id_paket',$id_paket);
        $this->db->update($table_paket, $data);
    }
    public function editx ($id_paket)
    {
        $this->db->where_in('jenis', array('kiloan','selimut','bed_cover','kaos','lain',));
        $this->db->where('id_paket',$id_paket);
        return $this->db->get('tb_paket')->row_array();

    }

    //delete user
    
    function delete_data($where,$table)
    {
        $this->db->delete($table,$where);
    }
}
