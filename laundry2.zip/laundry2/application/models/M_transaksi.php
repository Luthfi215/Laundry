<?php
defined('BASEPATH') or exit('No direct script access allowed');
class  M_transaksi extends CI_Model
{
    // show user&filter chose role_id
    public function tampil_data()
    {
        $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama');
        $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
        $this->db->from('tb_transaksi');
        $this->db->order_by('id_transaksi', 'desc');
        $query = $this->db->get();


        // $this->db->select('*');
        // $this->db->from('blogs');
        // $this->db->join('comments', 'comments.id = blogs.id');
        // $query = $this->db->get();

        return $query->result();

        // return $this->db->get('tb_transaksi')->result();
    }

    public function outlet()
    {

        return $this->db->get('tb_outlet')->result_array();
    }
    public function paket()
    {

        return $this->db->get('tb_paket')->result_array();
    }
    public function member()
    {

        return $this->db->get('tb_member')->result_array();
    }
    // tambah user
    public function insert_data()
    {
        $data = array(
            'kode_invoice' => ($this->input->post('kode_invoice')),
            'id_member' => ($this->input->post('id_member')),
            'id_outlet' => ($this->input->post('id_outlet')),
            'id_paket' => ($this->input->post('id_paket')),
            'bayar' => ($this->input->post('bayar')),
            'status' => ($this->input->post('status')),
            'jml_kilo' => ($this->input->post('jml_kilo', true)),
            'tgl' => ($this->input->post('tgl')),
            // 'tgl_bayar' => ($this->input->post('tgl_bayar'))

        );

        $this->db->insert('tb_transaksi', $data);
    }

    //edit user
    function edit_data($id_transaksi)
    {
        $data = array(
            'kode_invoice' => ($this->input->post('kode_invoice')),
            'id_member' => ($this->input->post('id_member')),
            'id_outlet' => ($this->input->post('id_outlet')),
            'id_paket' => ($this->input->post('id_paket')),
            'bayar' => ($this->input->post('bayar')),
            'tgl' => ($this->input->post('tgl')),
            'tgl_bayar' => ($this->input->post('tgl_bayar')),
            'jml_kilo' => ($this->input->post('jml_kilo', True)),
            'status' => ($this->input->post('status'))
        );
        $table_user = $this->db->dbprefix('tb_transaksi');

        $this->db->where('id_transaksi', $id_transaksi);
        $this->db->update($table_user, $data);
    }
    public function editx($id_transaksi)
    {
        $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama');
        $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
        $this->db->from('tb_transaksi');
        $this->db->where('id_transaksi', $id_transaksi);
        return $this->db->get()->row_array();
    }
    public function editxx($id_transaksi)
    {
        $this->db->select('tb_transaksi.*, tb_outlet.id_outlet, tb_outlet.nama');
        $this->db->join('tb_outlet', 'tb_transaksi.id_outlet = tb_outlet.id_outlet');
        $this->db->from('tb_transaksi');
        $this->db->where('id_transaksi', $id_transaksi);
        return $this->db->get()->row_array();
    }
    public function editxxx($id_transaksi)
    {
        $this->db->select('tb_transaksi.*, tb_paket.id_paket, tb_paket.nama_paket');
        $this->db->join('tb_paket', 'tb_transaksi.id_paket = tb_paket.id_paket');
        $this->db->from('tb_transaksi');
        $this->db->where('id_transaksi', $id_transaksi);
        return $this->db->get()->row_array();
    }

    //delete user

    function delete_data($where, $table)
    {
        $this->db->delete($table, $where);
    }

    public function no()
    {
        return $this->db->query("SELECT max(kode_invoice) AS kode FROM tb_transaksi");
    }

    function showall($tb, $prop) //kilo
    {
        return $this->db->query("SELECT * FROM $tb $prop");
    }
}
