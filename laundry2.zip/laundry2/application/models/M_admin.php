<?php
defined('BASEPATH') or exit('No direct script access allowed');
class  M_admin extends CI_Model
{
    // show user&filter chose role_id
    public function tampil_user()
    {
         $this->db->order_by('id_user', 'desc');
        return $this->db->get('tb_user')->result();
    }

    // tambah user
    public function insert_data()
    {
        $data = array(
            'nama' => ($this->input->post('nama')),
            'role' => ($this->input->post('role')),
            'username' => ($this->input->post('username')),
            'password' => md5($this->input->post('password'))
        );

        $this->db->insert('tb_user', $data);
    }
    
    //edit user
    function edit_data($id_user)
    {
        $data = array(
            'nama' => ($this->input->post('nama')),
            'role' => ($this->input->post('role')),
            'username' => ($this->input->post('username')),
            'password' => md5($this->input->post('password'))
        );
        $table_user = $this->db->dbprefix('tb_user');

        $this->db->where('id_user',$id_user);
        $this->db->update($table_user, $data);
    }
    public function editx ($id_user)
    {
        $this->db->where_in('role', array('Kasir','Owner','Admin'));
        $this->db->where('id_user',$id_user);
        return $this->db->get('tb_user')->row_array();

    }

    //delete user
    
    function delete_data($where,$table)
    {
        $this->db->delete($table,$where);
    }
}
