<?php
defined('BASEPATH') or exit('No direct script access allowed');
class  M_pelanggan extends CI_Model
{
    // show user&filter chose role_id
    public function tampil_member()
    {
         $this->db->order_by('id_member', 'desc');
        return $this->db->get('tb_member')->result();
    }

    // tambah user
    public function insert_data()
    {
        $data = array(
            'nama' => ($this->input->post('nama')),
            'alamat' => ($this->input->post('alamat')),
            'jenis_kelamin' => ($this->input->post('jenis_kelamin')),
            'tlp' => ($this->input->post('tlp'))
        );

        $this->db->insert('tb_member', $data);
    }
    
    //edit user
    public function edit_data($id_member)
    {
        $data = array(
            'nama' => ($this->input->post('nama')),
            'alamat' => ($this->input->post('alamat')),
            'jenis_kelamin' => ($this->input->post('jenis_kelamin')),
            'tlp' => ($this->input->post('tlp'))
        );
        $table_member = $this->db->dbprefix('tb_member');

        $this->db->where('id_member',$id_member);
        return $this->db->update($table_member, $data);
    }
    public function editx ($id_member)
    {
        // $this->db->where_in('jenis_kelamin', array('L','P'));
        $this->db->where('id_member',$id_member);
        return $this->db->get('tb_member')->row_array();

    }

    //delete user
    
    function delete_data($where,$table)
    {
        $this->db->delete($table,$where);
    }
}
