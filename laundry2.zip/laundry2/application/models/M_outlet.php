<?php
defined('BASEPATH') or exit('No direct script access allowed');
class  M_outlet extends CI_Model
{
    // show user&filter chose role_id
    public function tampil_outlet()
    {
         $this->db->order_by('id_outlet', 'desc');
        return $this->db->get('tb_outlet')->result();
    }

    // tambah user
    public function insert_data()
    {
        $data = array(
            'nama' => ($this->input->post('nama')),
            'alamat' => ($this->input->post('alamat')),
            'tlp' => ($this->input->post('tlp'))
            // 'password' => ($this->input->post('password'))
        );

        $this->db->insert('tb_outlet', $data);
    }
    
    //edit user
    function edit_data($id_outlet)
    {
        $data = array(
            'nama' => ($this->input->post('nama')),
            'alamat' => ($this->input->post('alamat')),
            'tlp' => ($this->input->post('tlp'))
            // 'password' => ($this->input->post('password'))
        );
        $table_outlet = $this->db->dbprefix('tb_outlet');

        $this->db->where('id_outlet',$id_outlet);
        $this->db->update($table_outlet, $data);
    }
     public function editx ($id_outlet)
     {
        // $this->db->where_in('role', array('Kasir','Owner'));
         $this->db->where('id_outlet',$id_outlet);
         return $this->db->get('tb_outlet')->row_array();

    }

    //delete user
    
    function delete_data($where,$table)
    {
        $this->db->delete($table,$where);
    }
}
