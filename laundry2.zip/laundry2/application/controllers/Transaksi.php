<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi extends CI_Controller
{

    function __construct()
    {
        parent::__construct();

        // date_default_timezone_set('Asian/Jakarta');

        $this->load->model('M_transaksi');

        if ($this->session->userdata('status') != "telah_login") {
            redirect(base_url() . 'login?alert=belum_login');
        }
    }
    public function index()
    {
        $data['transaksi'] = $this->M_transaksi->tampil_data();
        $this->load->view('template/header');
        $this->load->view('V_transaksi/transaksi', $data);
        $this->load->view('template/footer');
    }

    public function kilo() //javascript kalkulasi
    {
        $kilo = $_POST['jml_kilo']; //jml_kilo = total_berat
        $paket = $this->M_transaksi->showall('tb_paket', "WHERE id_paket = '$_POST[paket]' ")->row();
        if ($_POST['jml_kilo'] == "") {
            $total = "";
        } else {
            $total = $paket->harga * $kilo;
        }
        echo $total;
    }
    public function tambah()
    {
        $this->form_validation->set_rules('kode_invoice', 'kode_invoice', 'required|trim');
        $this->form_validation->set_rules('id_member', 'id_member', 'required|trim');
        // $this->form_validation->set_rules('bayar','bayar','required|trim');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required|trim');
        $this->form_validation->set_rules('id_paket', 'id_paket', 'required|trim');
        $this->form_validation->set_rules('tgl', 'tgl', 'required|trim');
        $this->form_validation->set_rules('jml_kilo', 'Jumlah Kilo', 'required|trim');
        $this->form_validation->set_rules('status', 'status', 'required|trim');



        if ($this->form_validation->run() == false) {
            $data['outlet'] = $this->M_transaksi->outlet();
            $data['paket'] = $this->M_transaksi->paket();
            $data['member'] = $this->M_transaksi->member();

            $qr = $this->M_transaksi->no()->row_array();
            $kode = $qr['kode'];
            $nu = (int) substr($kode, 6, 9);
            $nu++;
            $tgl = date('y');
            $data['no'] = "INV" . $tgl . sprintf('%04s', $nu);

            $this->load->view('template/header');
            $this->load->view('V_transaksi/T_transaksi', $data);
            $this->load->view('template/footer');
        } else {
            $this->M_transaksi->insert_data();
            $this->session->set_flashdata('Transaksi', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Transaksi berhasil ditambahkan!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>');
            redirect('Transaksi');
        }
    }

    // edit
    public function edit($id_transaksi)
    {

        $this->form_validation->set_rules('kode_invoice', 'kode_invoice', 'required|trim');
        $this->form_validation->set_rules('id_member', 'id_member', 'required|trim');
        $this->form_validation->set_rules('bayar', 'bayar', 'required|trim');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required|trim');
        $this->form_validation->set_rules('id_paket', 'id_paket', 'required|trim');
        $this->form_validation->set_rules('tgl', 'tgl', 'required|trim');
        $this->form_validation->set_rules('tgl_bayar', 'tgl_bayar', 'required|trim');
        $this->form_validation->set_rules('jml_kilo', 'jml_kilo', 'required|trim');
        $this->form_validation->set_rules('status', 'status', 'required|trim');
        // $this->form_validation->set_rules('password','password','required');

        if ($this->form_validation->run() == false) {
            $data['transaksi'] = $this->M_transaksi->editx($id_transaksi);
            $data['transaksi2'] = $this->M_transaksi->editxx($id_transaksi);
            $data['transaksi3'] = $this->M_transaksi->editxxx($id_transaksi);
            $this->load->view('template/header');
            $this->load->view('V_transaksi/E_transaksi', $data);
            $this->load->view('template/footer');
        } else {
            $this->M_transaksi->edit_data($id_transaksi);
            $this->session->set_flashdata('Transaksi', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Transaksi berhasil diupdate!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>');
            redirect('transaksi');
        }
    }
}
