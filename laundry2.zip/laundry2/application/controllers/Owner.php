<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Owner extends CI_Controller
{

    function __construct()
    {
        parent::__construct();

        // date_default_timezone_set('Asian/Jakarta');

        $this->load->model('M_laporan');

        if ($this->session->userdata('status') != "telah_login") {
            redirect(base_url() . 'login?alert=belum_login');
        }
    }
    public function index()
    {
        $data['memberv'] = $this->M_laporan->daftarpelanggan();
        $data['outletv'] = $this->M_laporan->daftaroutlet();
        $data['outler1'] = $this->M_laporan->editxx();
        $data['laporan'] = $this->M_laporan->tampil_data();
        $this->load->view('template/header');
        $this->load->view('V_laporan/laporan', $data);
        $this->load->view('template/footer');
    }
}