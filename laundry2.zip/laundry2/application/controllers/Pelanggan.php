<?php 
  defined("BASEPATH") OR exit('No direct script access allowed');

  class Pelanggan extends CI_Controller {
      
    function __construct()
    {
        parent::__construct();

        // date_default_timezone_set('Asian/Jakarta');

        $this->load->model('M_pelanggan');

        if($this->session->userdata('status')!="telah_login")
        {
            redirect(base_url().'login?alert=belum_login');

        }
    }

    public function index()
    {
        $data['member'] = $this->M_pelanggan->tampil_member(); // tabel

        $this->load->view('template/header');
        $this->load->view('V_pelanggan/pelanggan', $data);
        $this->load->view('template/footer');
    }

    // tambah
    public function tambah()
    {
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('jenis_kelamin','jenis_kelamin','required');
        $this->form_validation->set_rules('tlp','tlp','required');
        
        if ($this->form_validation->run() == false)
        {
            $this->load->view('template/header');
            $this->load->view('V_pelanggan/T_member');
            $this->load->view('template/footer');
            
        }
        else
        {
            $this->M_pelanggan->insert_data();
            redirect ('Pelanggan');
        }
    }

    // edit
    public function edit($id_member)
    {
    
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('jenis_kelamin','jenis_kelamin','required');
        $this->form_validation->set_rules('tlp','tlp','required');
        
        if ($this->form_validation->run() == false)
        {
            $data['member'] = $this->M_pelanggan->editx($id_member);
            $this->load->view('template/header');
            $this->load->view('V_pelanggan/E_pelanggan',$data);
            $this->load->view('template/footer');

            
        }
        else
        {
            $this->M_pelanggan->edit_data($id_member);
            redirect ('Pelanggan');
        }
    }



    public function member_hapus($id_member)
    {
        $where = array(
            'id_member' => $id_member
        );

        $this->M_pelanggan->delete_data($where,'tb_member');

        redirect(base_url().'Pelanggan');
    }

    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }
  }