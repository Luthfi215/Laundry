<?php
defined("BASEPATH") or exit('No direct script access allowed');

class Outlet extends CI_Controller
{

    function __construct()
    {
        parent::__construct();

        // date_default_timezone_set('Asian/Jakarta');

        $this->load->model('M_outlet');

        if ($this->session->userdata('status') != "telah_login") {
            redirect(base_url() . 'login?alert=belum_login');
        }
    }

    public function index()
    {
        $data['outlet'] = $this->M_outlet->tampil_outlet(); // tabel

        $this->load->view('template/header');
        $this->load->view('V_outlet/Outlet', $data);
        $this->load->view('template/footer');
    }

    // tambah
    public function tambah()
    {
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('alamat', 'alamat', 'required');
        $this->form_validation->set_rules('tlp', 'tlp', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('template/header');
            $this->load->view('V_outlet/T_outlet');
            $this->load->view('template/footer');
        } else {
            $this->M_outlet->insert_data();
            redirect('Outlet');
        }
    }

    // edit
    public function edit($id_outlet)
    {

        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('alamat', 'alamat', 'required');
        $this->form_validation->set_rules('tlp', 'tlp', 'required');
        // $this->form_validation->set_rules('password','password','required');

        if ($this->form_validation->run() == false) {
            $data['outlet'] = $this->M_outlet->editx($id_outlet);
            $this->load->view('template/header');
            $this->load->view('V_outlet/E_outlet', $data);
            $this->load->view('template/footer');
        } else {
            $this->M_outlet->edit_data($id_outlet);
            redirect('Outlet');
        }
    }



    public function member_hapus($id_outlet)
    {
        $where = array(
            'id_outlet' => $id_outlet
        );

        $this->M_outlet->delete_data($where, 'tb_outlet');

        redirect(base_url() . 'Outlet');
    }

    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }
}
