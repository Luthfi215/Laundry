<?php 
  defined("BASEPATH") OR exit('No direct script access allowed');

  class Paket extends CI_Controller {
      
    function __construct()
    {
        parent::__construct();

        // date_default_timezone_set('Asian/Jakarta');

        $this->load->model('M_paket');

        if($this->session->userdata('status')!="telah_login")
        {
            redirect(base_url().'login?alert=belum_login');

        }
    }

    public function index()
    {
        $data['paket'] = $this->M_paket->tampil_paket(); // tabel

        $this->load->view('template/header');
        $this->load->view('V_paket/paket', $data);
        $this->load->view('template/footer');
    }

    // tambah
    public function tambah()
    {
        $this->form_validation->set_rules('jenis','jenis','required');
        $this->form_validation->set_rules('nama_paket','nama_paket','required');
        $this->form_validation->set_rules('harga','harga','required');
        // $this->form_validation->set_rules('password','password','required');
        
        if ($this->form_validation->run() == false)
        {
            $this->load->view('template/header');
            $this->load->view('V_paket/T_paket');
            $this->load->view('template/footer');
            
        }
        else
        {
            $this->M_paket->insert_data();
            redirect ('Paket');
        }
    }

    // edit
    public function edit($id_paket)
    {
    
        $this->form_validation->set_rules('jenis','jenis','required');
        $this->form_validation->set_rules('nama_paket','nama_paket','required');
        $this->form_validation->set_rules('harga','harga','required');
        // $this->form_validation->set_rules('password','password','required');
        
        if ($this->form_validation->run() == false)
        {
            $data['paket'] = $this->M_paket->editx($id_paket);
            $this->load->view('template/header');
            $this->load->view('V_paket/E_paket',$data);
            $this->load->view('template/footer');

            
        }
        else
        {
            $this->M_paket->edit_data($id_paket);
            redirect ('Paket');
        }
    }



    public function member_hapus($id_paket)
    {
        $where = array(
            'id_paket' => $id_paket
        );

        $this->M_paket->delete_data($where,'tb_paket');

        redirect(base_url().'Paket');
    }

    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }
  }