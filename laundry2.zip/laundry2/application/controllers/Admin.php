  <?php 
  defined("BASEPATH") OR exit('No direct script access allowed');

  class Admin extends CI_Controller {
      
    function __construct()
    {
        parent::__construct();

        // date_default_timezone_set('Asian/Jakarta');

        $this->load->model('M_admin');

        if($this->session->userdata('status')!="telah_login")
        {
            redirect(base_url().'login?alert=belum_login');

        }
    }

    public function index()
    {
        $data['user'] = $this->M_admin->tampil_user(); // tabel

        $this->load->view('template/header');
        $this->load->view('V_pengguna/pengguna', $data);
        $this->load->view('template/footer');
    }

    // tambah
    public function tambah()
    {
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('role','role','required');
        $this->form_validation->set_rules('username','username','required');
        $this->form_validation->set_rules('password','password','required');
        
        if ($this->form_validation->run() == false)
        {
            $this->load->view('template/header');
            $this->load->view('V_pengguna/T_member');
            $this->load->view('template/footer');
            
        }
        else
        {
            $this->M_admin->insert_data();
            redirect ('Admin');
        }
    }

    // edit
    public function edit($id_user)
    {
    
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('role','role','required');
        $this->form_validation->set_rules('username','username','required');
        // $this->form_validation->set_rules('password','password','required');
        
        if ($this->form_validation->run() == false)
        {
            $data['user'] = $this->M_admin->editx($id_user);
            $this->load->view('template/header');
            $this->load->view('V_pengguna/E_pengguna',$data);
            $this->load->view('template/footer');

            
        }
        else
        {
            $this->M_admin->edit_data($id_user);
            redirect ('Admin');
        }
    }



    public function member_hapus($id_user)
    {
        $where = array(
            'id_user' => $id_user
        );

        $this->M_admin->delete_data($where,'tb_user');

        redirect(base_url().'admin');
    }

    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }
  }